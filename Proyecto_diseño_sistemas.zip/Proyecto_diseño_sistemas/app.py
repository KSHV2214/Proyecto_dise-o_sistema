from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash
from models import db, Usuario, Cliente, Servicio, Factura, PromocionQR, Institucion
from forms import LoginForm, ClienteForm, ServicioForm, FacturaForm, PromocionQRForm, InstitucionForm, EditarServicioForm
import qrcode
import os
from datetime import datetime, date, timedelta
import uuid
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from io import BytesIO
import base64
from sqlalchemy import func
from decimal import Decimal
import time
import sys

app = Flask(__name__)
app.config['SECRET_KEY'] = 'servicepro-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://servicepro_user:servicepro_pass@db:5432/servicepro_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['IVA_PERCENTAGE'] = 15  # IVA del 15%

# Inicializar extensiones
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, inicia sesión para acceder a esta página.'

def wait_for_db():
    """Espera a que la base de datos esté disponible"""
    max_retries = 30
    for i in range(max_retries):
        try:
            with app.app_context():
                from sqlalchemy import text
                db.session.execute(text('SELECT 1'))
                db.session.commit()
            print("✅ Conexión exitosa a la base de datos")
            return True
        except Exception as e:
            print(f"⏳ Esperando base de datos... Intento {i+1}/{max_retries}: {str(e)}")
            time.sleep(2)
    
    print("❌ No se pudo conectar a la base de datos después de todos los intentos")
    sys.exit(1)

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

# Funciones auxiliares
def registrar_servicio(tipo, descripcion, cliente_id, cantidad, precio_unitario):
    """Registra nuevo servicio y calcula precio automáticamente"""
    servicio = Servicio(
        tipo=tipo,
        descripcion=descripcion,
        cliente_id=cliente_id,
        cantidad=cantidad,
        precio_unitario=precio_unitario
    )
    servicio.calcular_precio_total()
    db.session.add(servicio)
    db.session.commit()
    return servicio

def generar_factura_pdf(factura_id):
    """Genera PDF de factura con logo y datos completos"""
    factura = Factura.query.get_or_404(factura_id)
    
    # Crear buffer para el PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    
    # Estilos
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        spaceAfter=30,
        alignment=1  # Center
    )
    
    # Título
    story.append(Paragraph("PAPELERÍA CYBERSIS", title_style))
    story.append(Paragraph("ServicePro - Sistema de Facturación", styles['Heading2']))
    story.append(Spacer(1, 20))
    
    # Información de la factura
    factura_info = [
        ['Número de Factura:', factura.numero_factura],
        ['Fecha:', factura.fecha.strftime('%d/%m/%Y %H:%M')],
        ['Cliente:', factura.cliente.nombre],
        ['Cédula:', factura.cliente.cedula],
    ]
    
    if factura.cliente.email:
        factura_info.append(['Email:', factura.cliente.email])
    if factura.cliente.telefono:
        factura_info.append(['Teléfono:', factura.cliente.telefono])
    
    factura_table = Table(factura_info, colWidths=[2*inch, 4*inch])
    factura_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
    ]))
    
    story.append(factura_table)
    story.append(Spacer(1, 20))
    
    # Servicios
    story.append(Paragraph("SERVICIOS FACTURADOS", styles['Heading3']))
    story.append(Spacer(1, 10))
    
    servicios_data = [['Tipo', 'Descripción', 'Cantidad', 'Precio Unit.', 'Total']]
    for servicio in factura.servicios:
        servicios_data.append([
            servicio.tipo.title(),
            servicio.descripcion,
            str(servicio.cantidad),
            f"${servicio.precio_unitario:.2f}",
            f"${servicio.precio_total:.2f}"
        ])
    
    servicios_table = Table(servicios_data, colWidths=[1.2*inch, 2.5*inch, 0.8*inch, 1*inch, 1*inch])
    servicios_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(servicios_table)
    story.append(Spacer(1, 20))
    
    # Totales
    totales_data = [
        ['Subtotal:', f"${factura.subtotal:.2f}"],
        ['IVA (15%):', f"${factura.iva:.2f}"]
    ]
    
    if factura.descuento > 0:
        totales_data.append(['Descuento:', f"-${factura.descuento:.2f}"])
    
    totales_data.append(['TOTAL:', f"${factura.total:.2f}"])
    
    totales_table = Table(totales_data, colWidths=[4*inch, 2*inch])
    totales_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('FONTSIZE', (0, -1), (-1, -1), 14),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, -1), (-1, -1), 12),
        ('LINEABOVE', (0, -1), (-1, -1), 2, colors.black),
    ]))
    
    story.append(totales_table)
    
    # Construir PDF
    doc.build(story)
    buffer.seek(0)
    
    # Guardar en el sistema de archivos
    pdf_path = f"/app/static/facturas/factura_{factura.numero_factura}.pdf"
    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
    
    with open(pdf_path, 'wb') as f:
        f.write(buffer.getvalue())
    
    return buffer

def crear_promocion_qr(codigo_personalizado, descuento, vigencia_dias, descripcion, instituciones_ids=None):
    """Crea promoción y genera código QR único"""
    # Usar código personalizado del usuario
    codigo_qr = codigo_personalizado.upper()  # Convertir a mayúsculas para consistencia
    fecha_fin = date.today() + timedelta(days=vigencia_dias)
    
    promocion = PromocionQR(
        codigo_qr=codigo_qr,
        descripcion=descripcion,
        descuento_porcentaje=descuento,
        fecha_fin=fecha_fin
    )
    
    db.session.add(promocion)
    db.session.flush()  # Para obtener el ID
    
    # Asignar instituciones si se proporcionan
    if instituciones_ids:
        instituciones = Institucion.query.filter(Institucion.id.in_(instituciones_ids)).all()
        promocion.instituciones.extend(instituciones)
    
    # Generar código QR con el código personalizado
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(codigo_qr)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Guardar imagen QR
    qr_path = f"/app/static/qr_codes/promo_{promocion.id}.png"
    os.makedirs(os.path.dirname(qr_path), exist_ok=True)
    img.save(qr_path)
    
    db.session.commit()
    return promocion

def validar_qr_promocion(codigo_qr):
    """Valida código QR y retorna descuento si es válido"""
    promocion = PromocionQR.query.filter_by(codigo_qr=codigo_qr).first()
    
    if promocion and promocion.is_valid():
        return promocion
    return None

def calcular_estadisticas_promociones():
    """Calcula efectividad de promociones QR"""
    promociones = PromocionQR.query.all()
    estadisticas = []
    
    for promo in promociones:
        efectividad = (promo.usos_actuales / promo.usos_maximos) * 100 if promo.usos_maximos > 0 else 0
        estadisticas.append({
            'id': promo.id,
            'descripcion': promo.descripcion,
            'usos_actuales': promo.usos_actuales,
            'usos_maximos': promo.usos_maximos,
            'efectividad': efectividad,
            'activa': promo.activa
        })
    
    return estadisticas

def init_docker_data():
    """Inicializa datos de prueba para demostración"""
    print("Inicializando datos de prueba...")
    
    # Crear usuarios
    admin = Usuario(username='admin', rol='administrador')
    admin.set_password('admin123')
    
    empleado = Usuario(username='empleado', rol='empleado')
    empleado.set_password('emp123')
    
    db.session.add_all([admin, empleado])
    
    # Crear instituciones
    instituciones = [
        Institucion(nombre='Universidad Central', contacto='María González', email='maria@uc.edu', telefono='0987654321'),
        Institucion(nombre='Colegio San José', contacto='Pedro Martínez', email='pedro@sanjose.edu', telefono='0987654322')
    ]
    db.session.add_all(instituciones)
    
    # Crear clientes
    clientes = [
        Cliente(nombre='Juan Pérez', cedula='1234567890', email='juan@email.com', telefono='0987654321'),
        Cliente(nombre='María García', cedula='0987654321', email='maria@email.com', telefono='0987654322'),
        Cliente(nombre='Carlos López', cedula='1122334455', email='carlos@email.com'),
        Cliente(nombre='Ana Martínez', cedula='5544332211', email='ana@email.com'),
        Cliente(nombre='Luis Rodríguez', cedula='9988776655', telefono='0987654323'),
        Cliente(nombre='Patricia Hernández', cedula='5566778899', email='patricia@email.com'),
        Cliente(nombre='Diego Morales', cedula='3344556677', telefono='0987654324'),
        Cliente(nombre='Carmen Vega', cedula='7788990011', email='carmen@email.com'),
        Cliente(nombre='Roberto Silva', cedula='2233445566', telefono='0987654325'),
        Cliente(nombre='Elena Castro', cedula='6677889900', email='elena@email.com')
    ]
    db.session.add_all(clientes)
    db.session.commit()
    
    # Crear servicios
    servicios = [
        Servicio(tipo='impresion', descripcion='Impresión de tesis 200 páginas', precio_unitario=Decimal('0.05'), cantidad=200, cliente_id=1),
        Servicio(tipo='fotocopiado', descripcion='Fotocopias de documentos', precio_unitario=Decimal('0.02'), cantidad=100, cliente_id=2),
        Servicio(tipo='encuadernacion', descripcion='Encuadernación de tesis', precio_unitario=Decimal('5.00'), cantidad=1, cliente_id=1),
        Servicio(tipo='impresion', descripcion='Impresión a color', precio_unitario=Decimal('0.15'), cantidad=50, cliente_id=3),
        Servicio(tipo='fotocopiado', descripcion='Copias de libros', precio_unitario=Decimal('0.02'), cantidad=300, cliente_id=4),
        Servicio(tipo='encuadernacion', descripcion='Encuadernación anillada', precio_unitario=Decimal('3.00'), cantidad=2, cliente_id=5),
        Servicio(tipo='impresion', descripcion='Impresión de folletos', precio_unitario=Decimal('0.10'), cantidad=100, cliente_id=6),
        Servicio(tipo='fotocopiado', descripcion='Fotocopias de exámenes', precio_unitario=Decimal('0.02'), cantidad=150, cliente_id=7, estado='completado'),
        Servicio(tipo='encuadernacion', descripcion='Encuadernación en pasta dura', precio_unitario=Decimal('8.00'), cantidad=1, cliente_id=8, estado='completado'),
        Servicio(tipo='impresion', descripcion='Impresión de carteles', precio_unitario=Decimal('2.00'), cantidad=5, cliente_id=9, estado='proceso'),
        Servicio(tipo='fotocopiado', descripcion='Copias de manuales', precio_unitario=Decimal('0.02'), cantidad=500, cliente_id=10),
        Servicio(tipo='impresion', descripcion='Impresión de certificados', precio_unitario=Decimal('1.00'), cantidad=10, cliente_id=1, estado='completado'),
        Servicio(tipo='encuadernacion', descripcion='Encuadernación espiral', precio_unitario=Decimal('2.50'), cantidad=3, cliente_id=2, estado='completado'),
        Servicio(tipo='impresion', descripcion='Impresión de tarjetas', precio_unitario=Decimal('0.50'), cantidad=20, cliente_id=3, estado='completado'),
        Servicio(tipo='fotocopiado', descripcion='Copias ampliadas', precio_unitario=Decimal('0.05'), cantidad=80, cliente_id=4, estado='completado')
    ]
    
    for servicio in servicios:
        servicio.calcular_precio_total()
        if servicio.estado == 'completado':
            servicio.fecha_completado = datetime.utcnow()
    
    db.session.add_all(servicios)
    db.session.commit()
    
    # Crear promociones QR
    promocion1 = crear_promocion_qr(10, 30, "Descuento estudiantes universitarios", [1])
    promocion2 = crear_promocion_qr(15, 60, "Promoción colegios", [2])
    promocion3 = crear_promocion_qr(5, 15, "Descuento por volumen")
    
    print("Datos de prueba inicializados correctamente!")

# Rutas de la aplicación
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = Usuario.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data) and user.activo:
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        flash('Usuario o contraseña incorrectos')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Estadísticas del dashboard
    total_servicios = Servicio.query.count()
    servicios_pendientes = Servicio.query.filter_by(estado='pendiente').count()
    servicios_completados = Servicio.query.filter_by(estado='completado').count()
    total_facturas = Factura.query.count()
    promociones_activas = PromocionQR.query.filter_by(activa=True).count()
    
    # Ingresos del mes
    mes_actual = datetime.now().month
    año_actual = datetime.now().year
    ingresos_mes = db.session.query(func.sum(Factura.total)).filter(
        func.extract('month', Factura.fecha) == mes_actual,
        func.extract('year', Factura.fecha) == año_actual
    ).scalar() or 0
    
    # Servicios por tipo
    servicios_por_tipo = db.session.query(
        Servicio.tipo, func.count(Servicio.id)
    ).group_by(Servicio.tipo).all()
    
    # Servicios recientes
    servicios_recientes = Servicio.query.order_by(Servicio.fecha_solicitud.desc()).limit(5).all()
    
    return render_template('dashboard.html',
                         total_servicios=total_servicios,
                         servicios_pendientes=servicios_pendientes,
                         servicios_completados=servicios_completados,
                         total_facturas=total_facturas,
                         promociones_activas=promociones_activas,
                         ingresos_mes=ingresos_mes,
                         servicios_por_tipo=servicios_por_tipo,
                         servicios_recientes=servicios_recientes)

@app.route('/servicios')
@login_required
def servicios():
    page = request.args.get('page', 1, type=int)
    tipo_filter = request.args.get('tipo', '')
    estado_filter = request.args.get('estado', '')
    
    query = Servicio.query
    
    if tipo_filter:
        query = query.filter_by(tipo=tipo_filter)
    if estado_filter:
        query = query.filter_by(estado=estado_filter)
    
    servicios = query.order_by(Servicio.fecha_solicitud.desc()).paginate(
        page=page, per_page=10, error_out=False)
    
    return render_template('servicios/lista.html', servicios=servicios,
                         tipo_filter=tipo_filter, estado_filter=estado_filter)

@app.route('/servicios/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_servicio():
    form = ServicioForm()
    form.cliente_id.choices = [(c.id, f"{c.nombre} - {c.cedula}") for c in Cliente.query.all()]
    
    if form.validate_on_submit():
        servicio = registrar_servicio(
            tipo=form.tipo.data,
            descripcion=form.descripcion.data,
            cliente_id=form.cliente_id.data,
            cantidad=form.cantidad.data,
            precio_unitario=form.precio_unitario.data
        )
        flash('Servicio registrado exitosamente')
        return redirect(url_for('servicios'))
    
    return render_template('servicios/nuevo.html', form=form)

@app.route('/servicios/<int:id>/editar', methods=['GET', 'POST'])
@login_required
def editar_servicio(id):
    servicio = Servicio.query.get_or_404(id)
    form = EditarServicioForm(obj=servicio)
    
    if form.validate_on_submit():
        servicio.estado = form.estado.data
        servicio.descripcion = form.descripcion.data
        servicio.precio_unitario = form.precio_unitario.data
        servicio.cantidad = form.cantidad.data
        servicio.calcular_precio_total()
        
        if form.estado.data == 'completado' and not servicio.fecha_completado:
            servicio.fecha_completado = datetime.utcnow()
        
        db.session.commit()
        flash('Servicio actualizado exitosamente')
        return redirect(url_for('servicios'))
    
    return render_template('servicios/editar.html', form=form, servicio=servicio)

@app.route('/servicios/<int:id>/eliminar', methods=['POST'])
@login_required
def eliminar_servicio(id):
    servicio = Servicio.query.get_or_404(id)
    try:
        db.session.delete(servicio)
        db.session.commit()
        flash(f'Servicio "{servicio.nombre}" eliminado exitosamente', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error al eliminar el servicio. Puede estar siendo usado en una factura.', 'error')
    
    return redirect(url_for('servicios'))

@app.route('/clientes')
@login_required
def clientes():
    page = request.args.get('page', 1, type=int)
    clientes = Cliente.query.paginate(page=page, per_page=10, error_out=False)
    return render_template('clientes/lista_clientes.html', clientes=clientes)

@app.route('/clientes/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_cliente():
    form = ClienteForm()
    
    if form.validate_on_submit():
        cliente = Cliente(
            nombre=form.nombre.data,
            cedula=form.cedula.data,
            email=form.email.data,
            telefono=form.telefono.data,
            direccion=form.direccion.data
        )
        db.session.add(cliente)
        db.session.commit()
        flash('Cliente registrado exitosamente')
        return redirect(url_for('clientes'))
    
    return render_template('clientes/nuevo_cliente.html', form=form)

@app.route('/clientes/<int:id>/editar', methods=['GET', 'POST'])
@login_required
def editar_cliente(id):
    cliente = Cliente.query.get_or_404(id)
    form = ClienteForm(obj=cliente)
    
    if form.validate_on_submit():
        cliente.nombre = form.nombre.data
        cliente.cedula = form.cedula.data
        cliente.email = form.email.data
        cliente.telefono = form.telefono.data
        cliente.direccion = form.direccion.data
        
        db.session.commit()
        flash('Cliente actualizado exitosamente')
        return redirect(url_for('clientes'))
    
    return render_template('clientes/editar_cliente.html', form=form, cliente=cliente)

@app.route('/clientes/<int:id>/eliminar', methods=['POST'])
@login_required
def eliminar_cliente(id):
    cliente = Cliente.query.get_or_404(id)
    try:
        # Eliminar servicios asociados primero
        Servicio.query.filter_by(cliente_id=id).delete()
        db.session.delete(cliente)
        db.session.commit()
        flash(f'Cliente "{cliente.nombre}" eliminado exitosamente', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error al eliminar el cliente. Puede estar siendo usado en una factura.', 'error')
    
    return redirect(url_for('clientes'))

@app.route('/facturas')
@login_required
def facturas():
    page = request.args.get('page', 1, type=int)
    facturas = Factura.query.order_by(Factura.fecha.desc()).paginate(
        page=page, per_page=10, error_out=False)
    return render_template('facturas/lista_facturas.html', facturas=facturas)

@app.route('/facturas/nueva', methods=['GET', 'POST'])
@login_required
def nueva_factura():
    form = FacturaForm()
    form.cliente_id.choices = [(c.id, f"{c.nombre} - {c.cedula}") for c in Cliente.query.all()]
    
    if form.validate_on_submit():
        try:
            # Obtener servicios válidos primero
            servicios_ids = [int(x.strip()) for x in form.servicios_ids.data.split(',') if x.strip()]
            servicios = Servicio.query.filter(
                Servicio.id.in_(servicios_ids), 
                Servicio.estado == 'completado',
                Servicio.factura_id.is_(None)
            ).all()
            
            if not servicios:
                flash('No se encontraron servicios válidos para facturar. Los servicios deben estar completados y no facturados.', 'error')
                return render_template('facturas/nueva.html', form=form)
            
            # Generar número de factura
            ultimo_numero = db.session.query(func.max(Factura.id)).scalar() or 0
            numero_factura = f"FAC-{ultimo_numero + 1:06d}"
            
            # Calcular totales ANTES de crear la factura
            subtotal = Decimal('0')
            for servicio in servicios:
                subtotal += servicio.precio_total
            
            # Aplicar promoción si existe
            descuento = Decimal('0')
            promocion = None
            if form.promocion_qr.data:
                promocion = validar_qr_promocion(form.promocion_qr.data)
                if promocion and promocion.is_valid():
                    descuento = subtotal * (promocion.descuento_porcentaje / Decimal('100'))
            
            # Calcular IVA y total
            iva_percentage = Decimal(str(app.config.get('IVA_PERCENTAGE', 15)))
            iva = subtotal * (iva_percentage / Decimal('100'))
            total = subtotal + iva - descuento
            
            # Crear factura CON todos los valores calculados
            factura = Factura(
                numero_factura=numero_factura,
                cliente_id=form.cliente_id.data,
                subtotal=subtotal,
                iva=iva,
                descuento=descuento,
                total=total,
                promocion_id=promocion.id if promocion else None
            )
            
            # Guardar todo en una transacción
            db.session.add(factura)
            db.session.flush()  # Obtener ID de factura
            
            # Asignar servicios a la factura
            for servicio in servicios:
                servicio.factura_id = factura.id
            
            # Usar promoción si existe
            if promocion:
                promocion.usar_promocion()
            
            db.session.commit()
            
            # ELIMINAR SERVICIOS AUTOMÁTICAMENTE DESPUÉS DE FACTURAR
            try:
                for servicio in servicios:
                    db.session.delete(servicio)
                db.session.commit()
                flash(f'Factura generada exitosamente y {len(servicios)} servicios eliminados automáticamente', 'success')
            except Exception as e:
                # Si hay error al eliminar, al menos la factura ya está guardada
                app.logger.error(f'Error al eliminar servicios después de facturar: {str(e)}')
                flash('Factura generada exitosamente, pero algunos servicios no pudieron ser eliminados', 'warning')
            
            return redirect(url_for('ver_factura', id=factura.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al generar la factura: {str(e)}', 'error')
            app.logger.error(f'Error en nueva_factura: {str(e)}')
            return render_template('facturas/nueva.html', form=form)
    
    # Obtener servicios completados sin facturar
    servicios_disponibles = Servicio.query.filter_by(estado='completado').filter(
        Servicio.factura_id.is_(None)).all()
    
    return render_template('facturas/nueva.html', form=form, 
                         servicios_disponibles=servicios_disponibles)

@app.route('/facturas/<int:id>')
@login_required
def ver_factura(id):
    factura = Factura.query.get_or_404(id)
    return render_template('facturas/detalle.html', factura=factura)

@app.route('/facturas/<int:id>/pdf')
@login_required
def descargar_factura_pdf(id):
    buffer = generar_factura_pdf(id)
    factura = Factura.query.get_or_404(id)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'factura_{factura.numero_factura}.pdf',
        mimetype='application/pdf'
    )

@app.route('/promociones')
@login_required
def promociones():
    promociones = PromocionQR.query.order_by(PromocionQR.fecha_creacion.desc()).all()
    return render_template('promociones/lista.html', promociones=promociones, date=date)

@app.route('/promociones/nueva', methods=['GET', 'POST'])
@login_required
def nueva_promocion():
    form = PromocionQRForm()
    
    if form.validate_on_submit():
        # Verificar que el código no existe ya
        codigo_existente = PromocionQR.query.filter_by(codigo_qr=form.codigo_qr.data.upper()).first()
        if codigo_existente:
            flash('Este código de promoción ya existe. Por favor, elige otro.', 'error')
            return render_template('promociones/nueva.html', form=form, instituciones=Institucion.query.all())
        
        instituciones_ids = []
        if form.instituciones_ids.data:
            instituciones_ids = [int(x.strip()) for x in form.instituciones_ids.data.split(',') if x.strip()]
        
        promocion = crear_promocion_qr(
            codigo_personalizado=form.codigo_qr.data,
            descuento=form.descuento_porcentaje.data,
            vigencia_dias=(form.fecha_fin.data - date.today()).days,
            descripcion=form.descripcion.data,
            instituciones_ids=instituciones_ids
        )
        
        flash('Promoción QR creada exitosamente')
        return redirect(url_for('promociones'))
    
    instituciones = Institucion.query.all()
    return render_template('promociones/nueva.html', form=form, instituciones=instituciones)

@app.route('/promociones/<int:id>/qr')
@login_required
def ver_qr_promocion(id):
    promocion = PromocionQR.query.get_or_404(id)
    qr_path = f"qr_codes/promo_{promocion.id}.png"
    return render_template('promociones/qr.html', promocion=promocion, qr_path=qr_path)

@app.route('/api/validar-qr', methods=['POST'])
@login_required
def api_validar_qr():
    codigo = request.json.get('codigo')
    promocion = validar_qr_promocion(codigo)
    
    if promocion:
        return jsonify({
            'valido': True,
            'descuento': float(promocion.descuento_porcentaje),
            'descripcion': promocion.descripcion
        })
    else:
        return jsonify({'valido': False})

@app.route('/instituciones')
@login_required
def instituciones():
    instituciones = Institucion.query.all()
    return render_template('instituciones/lista.html', instituciones=instituciones)

@app.route('/instituciones/nueva', methods=['GET', 'POST'])
@login_required
def nueva_institucion():
    form = InstitucionForm()
    
    if form.validate_on_submit():
        institucion = Institucion(
            nombre=form.nombre.data,
            contacto=form.contacto.data,
            email=form.email.data,
            telefono=form.telefono.data
        )
        db.session.add(institucion)
        db.session.commit()
        flash('Institución registrada exitosamente')
        return redirect(url_for('instituciones'))
    
    return render_template('instituciones/nueva.html', form=form)

@app.route('/reportes')
@login_required
def reportes():
    # Estadísticas de promociones
    estadisticas_promociones = calcular_estadisticas_promociones()
    
    # Ingresos por mes (últimos 6 meses)
    ingresos_mensuales = []
    for i in range(6):
        fecha = datetime.now() - timedelta(days=30*i)
        ingresos = db.session.query(func.sum(Factura.total)).filter(
            func.extract('month', Factura.fecha) == fecha.month,
            func.extract('year', Factura.fecha) == fecha.year
        ).scalar() or 0
        ingresos_mensuales.append({
            'mes': fecha.strftime('%B'),
            'ingresos': float(ingresos)
        })
    
    ingresos_mensuales.reverse()
    
    return render_template('reportes.html', 
                         estadisticas_promociones=estadisticas_promociones,
                         ingresos_mensuales=ingresos_mensuales)

@app.route('/sistema/verificar')
@login_required
def verificar_sistema():
    """Ruta para verificar la configuración del sistema y estado de la base de datos"""
    try:
        # Verificar configuración de IVA
        iva_config = app.config.get('IVA_PERCENTAGE', 'No configurado')
        
        # Verificar conexión a base de datos
        total_clientes = Cliente.query.count()
        total_servicios = Servicio.query.count()
        total_facturas = Factura.query.count()
        
        # Verificar última factura generada
        ultima_factura = Factura.query.order_by(Factura.id.desc()).first()
        
        # Información del sistema
        info_sistema = {
            'iva_configurado': f"{iva_config}%",
            'conexion_bd': 'Conectada correctamente',
            'total_clientes': total_clientes,
            'total_servicios': total_servicios,
            'total_facturas': total_facturas,
            'ultima_factura': {
                'numero': ultima_factura.numero_factura if ultima_factura else 'Sin facturas',
                'fecha': ultima_factura.fecha.strftime('%d/%m/%Y %H:%M') if ultima_factura else 'N/A',
                'iva_aplicado': f"{ultima_factura.iva}" if ultima_factura else 'N/A',
                'total': f"{ultima_factura.total}" if ultima_factura else 'N/A'
            },
            'timestamp_verificacion': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        }
        
        return render_template('sistema/verificar.html', info=info_sistema)
        
    except Exception as e:
        flash(f'Error al verificar el sistema: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/sistema/limpiar-servicios')
@login_required
def limpiar_servicios_facturados():
    """Elimina todos los servicios que ya han sido facturados"""
    try:
        servicios_facturados = Servicio.query.filter(Servicio.factura_id.isnot(None)).all()
        count = len(servicios_facturados)
        
        for servicio in servicios_facturados:
            db.session.delete(servicio)
        
        db.session.commit()
        flash(f'Se eliminaron {count} servicios que ya estaban facturados', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error al limpiar servicios: {str(e)}', 'error')
    
    return redirect(url_for('servicios'))

# Inicializar la aplicación
def init_app():
    """Inicializa BD y datos de prueba solo si no existen"""
    # Esperar a que la base de datos esté disponible
    wait_for_db()
    
    with app.app_context():
        db.create_all()
        
        # Verificar si ya hay datos
        if Usuario.query.count() == 0:
            init_docker_data()

if __name__ == '__main__':
    init_app()
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
