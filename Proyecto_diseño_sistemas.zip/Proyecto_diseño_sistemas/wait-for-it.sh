#!/bin/bash
set -e

host="$1"
shift
cmd="$@"

until pg_isready -h "$host" -p 5432 -U servicepro_user; do
  >&2 echo "PostgreSQL no está disponible - esperando..."
  sleep 1
done

>&2 echo "PostgreSQL está disponible - ejecutando comando"
exec $cmd
