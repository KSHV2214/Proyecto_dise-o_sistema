from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import uuid

db = SQLAlchemy()

class Usuario(UserMixin, db.Model):
    __tablename__ = 'usuarios'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    rol = db.Column(db.String(20), nullable=False, default='empleado')  # empleado/administrador
    activo = db.Column(db.Boolean, default=True)
    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        return self.rol == 'administrador'

class Cliente(db.Model):
    __tablename__ = 'clientes'
    
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    cedula = db.Column(db.String(10), unique=True, nullable=False)
    email = db.Column(db.String(100))
    telefono = db.Column(db.String(15))
    direccion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    servicios = db.relationship('Servicio', backref='cliente', lazy=True)
    facturas = db.relationship('Factura', backref='cliente', lazy=True)

class Servicio(db.Model):
    __tablename__ = 'servicios'
    
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(50), nullable=False)  # impresion/fotocopiado/encuadernacion
    descripcion = db.Column(db.Text, nullable=False)
    precio_unitario = db.Column(db.Numeric(10, 2), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_total = db.Column(db.Numeric(10, 2), nullable=False)
    estado = db.Column(db.String(20), nullable=False, default='pendiente')  # pendiente/proceso/completado
    fecha_solicitud = db.Column(db.DateTime, default=datetime.utcnow)
    fecha_completado = db.Column(db.DateTime)
    
    # Relaciones
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.id'), nullable=False)
    factura_id = db.Column(db.Integer, db.ForeignKey('facturas.id'))
    
    def calcular_precio_total(self):
        self.precio_total = self.precio_unitario * self.cantidad

class Factura(db.Model):
    __tablename__ = 'facturas'
    
    id = db.Column(db.Integer, primary_key=True)
    numero_factura = db.Column(db.String(20), unique=True, nullable=False)
    fecha = db.Column(db.DateTime, default=datetime.utcnow)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    iva = db.Column(db.Numeric(10, 2), nullable=False)
    descuento = db.Column(db.Numeric(10, 2), default=0)
    total = db.Column(db.Numeric(10, 2), nullable=False)
    
    # Relaciones
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.id'), nullable=False)
    servicios = db.relationship('Servicio', backref='factura', lazy=True)
    promocion_id = db.Column(db.Integer, db.ForeignKey('promociones_qr.id'))
    
    def calcular_totales(self, iva_percentage=15):
        from decimal import Decimal
        if not self.servicios:
            self.subtotal = Decimal('0')
        else:
            self.subtotal = sum([s.precio_total for s in self.servicios])
        
        if not self.descuento:
            self.descuento = Decimal('0')
            
        self.iva = self.subtotal * (Decimal(str(iva_percentage)) / Decimal('100'))
        self.total = self.subtotal + self.iva - self.descuento

class PromocionQR(db.Model):
    __tablename__ = 'promociones_qr'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo_qr = db.Column(db.String(100), unique=True, nullable=False)
    descripcion = db.Column(db.Text, nullable=False)
    descuento_porcentaje = db.Column(db.Numeric(5, 2), nullable=False)
    fecha_inicio = db.Column(db.Date, default=date.today)
    fecha_fin = db.Column(db.Date, nullable=False)
    usos_maximos = db.Column(db.Integer, default=100)
    usos_actuales = db.Column(db.Integer, default=0)
    activa = db.Column(db.Boolean, default=True)
    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    facturas = db.relationship('Factura', backref='promocion', lazy=True)
    instituciones = db.relationship('Institucion', secondary='institucion_promocion', backref='promociones')
    
    def is_valid(self):
        today = date.today()
        return (self.activa and 
                self.fecha_inicio <= today <= self.fecha_fin and
                self.usos_actuales < self.usos_maximos)
    
    def usar_promocion(self):
        if self.is_valid():
            self.usos_actuales += 1
            return True
        return False

class Institucion(db.Model):
    __tablename__ = 'instituciones'
    
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    contacto = db.Column(db.String(100))
    email = db.Column(db.String(100))
    telefono = db.Column(db.String(15))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)

# Tabla intermedia para relación many-to-many entre Institucion y PromocionQR
institucion_promocion = db.Table('institucion_promocion',
    db.Column('institucion_id', db.Integer, db.ForeignKey('instituciones.id'), primary_key=True),
    db.Column('promocion_id', db.Integer, db.ForeignKey('promociones_qr.id'), primary_key=True)
)
