#!/bin/bash
# Script de backup automático para PostgreSQL

# Variables
DB_HOST="db"
DB_USER="servicepro_user"
DB_NAME="servicepro_db"
BACKUP_DIR="/backups"
DATE=$(date +"%Y%m%d_%H%M%S")

# Crear directorio de backups si no existe
mkdir -p $BACKUP_DIR

# Realizar backup
pg_dump -h $DB_HOST -U $DB_USER -d $DB_NAME > $BACKUP_DIR/backup_$DATE.sql

# Mantener solo los últimos 30 backups
find $BACKUP_DIR -name "backup_*.sql" -type f -mtime +30 -delete

echo "Backup completado: backup_$DATE.sql"
