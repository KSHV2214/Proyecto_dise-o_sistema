# Comandos para subir a GitHub (ejecutar después de instalar Git)

# 1. Configurar Git (solo la primera vez)
git config --global user.name "Tu Nombre"
git config --global user.email "tu.email@ejemplo.com"

# 2. Inicializar repositorio
git init

# 3. Agregar archivos
git add .

# 4. Primer commit
git commit -m "Initial commit: ServicePro sistema completo con IVA 15% y eliminación automática"

# 5. Crear repositorio en GitHub.com primero, luego:
git branch -M main
git remote add origin https://github.com/TU-USUARIO/servicepro.git
git push -u origin main

# Comandos adicionales útiles:
# Ver estado
git status

# Ver historial
git log --oneline

# Agregar cambios futuros
git add .
git commit -m "Descripción de cambios"
git push
