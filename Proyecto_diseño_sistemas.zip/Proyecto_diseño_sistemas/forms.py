from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, DecimalField, DateField, BooleanField, PasswordField
from wtforms.validators import DataRequired, Email, NumberRange, Optional, Length
from wtforms.widgets import TextArea

class LoginForm(FlaskForm):
    username = StringField('Usuario', validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField('Contraseña', validators=[DataRequired()])

class ClienteForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(max=100)])
    cedula = StringField('Cédula', validators=[DataRequired(), Length(min=10, max=10)])
    email = StringField('Email', validators=[Optional(), Email()])
    telefono = StringField('Teléfono', validators=[Optional(), Length(max=15)])
    direccion = TextAreaField('Dirección', validators=[Optional()])

class ServicioForm(FlaskForm):
    tipo = SelectField('Tipo de Servicio', 
                      choices=[('impresion', 'Impresión'), 
                              ('fotocopiado', 'Fotocopiado'), 
                              ('encuadernacion', 'Encuadernación')],
                      validators=[DataRequired()])
    descripcion = TextAreaField('Descripción', validators=[DataRequired()])
    precio_unitario = DecimalField('Precio Unitario', validators=[DataRequired(), NumberRange(min=0.01)])
    cantidad = IntegerField('Cantidad', validators=[DataRequired(), NumberRange(min=1)])
    cliente_id = SelectField('Cliente', coerce=int, validators=[DataRequired()])

class FacturaForm(FlaskForm):
    cliente_id = SelectField('Cliente', coerce=int, validators=[DataRequired()])
    servicios_ids = StringField('IDs de Servicios (separados por comas)', validators=[DataRequired()])
    promocion_qr = StringField('Código QR Promoción', validators=[Optional()])

class PromocionQRForm(FlaskForm):
    codigo_qr = StringField('Código de Promoción', validators=[DataRequired(), Length(min=3, max=20)], 
                           render_kw={"placeholder": "Ej: DESCUENTO20, ESTUDIANTE10"})
    descripcion = TextAreaField('Descripción', validators=[DataRequired()])
    descuento_porcentaje = DecimalField('Descuento (%)', validators=[DataRequired(), NumberRange(min=1, max=100)])
    fecha_fin = DateField('Fecha de Vencimiento', validators=[DataRequired()])
    usos_maximos = IntegerField('Usos Máximos', validators=[DataRequired(), NumberRange(min=1)])
    instituciones_ids = StringField('IDs de Instituciones (separados por comas)', validators=[Optional()])

class InstitucionForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(max=100)])
    contacto = StringField('Contacto', validators=[Optional(), Length(max=100)])
    email = StringField('Email', validators=[Optional(), Email()])
    telefono = StringField('Teléfono', validators=[Optional(), Length(max=15)])

class EditarServicioForm(FlaskForm):
    estado = SelectField('Estado', 
                        choices=[('pendiente', 'Pendiente'), 
                                ('proceso', 'En Proceso'), 
                                ('completado', 'Completado')],
                        validators=[DataRequired()])
    descripcion = TextAreaField('Descripción', validators=[DataRequired()])
    precio_unitario = DecimalField('Precio Unitario', validators=[DataRequired(), NumberRange(min=0.01)])
    cantidad = IntegerField('Cantidad', validators=[DataRequired(), NumberRange(min=1)])
