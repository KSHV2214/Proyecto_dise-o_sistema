# 🧪 GUÍA DE PRUEBAS MANUALES - SERVICEPRO
## Manual Completo para Verificar Todas las Funcionalidades

---

## 🚀 **PASO 0: PREPARACIÓN**

### Verificar que el sistema esté corriendo:
1. Abrir PowerShell en: `C:\Users\DOCENTE\Documents\Proyecto_diseño_sistemas`
2. Ejecutar: `docker ps`
3. Verificar que estén corriendo:
   - `proyecto_diseo_sistemas-web-1` (puerto 5000)
   - `proyecto_diseo_sistemas-db-1` (puerto 5433)

### Acceder al sistema:
- **URL**: http://localhost:5000
- **Usuario**: `admin`
- **Contraseña**: `admin123`

---

## 🔐 **PASO 1: PRUEBA DE AUTENTICACIÓN**

### 1.1 Probar Login Exitoso
1. Ir a: http://localhost:5000
2. Debería redirigir automáticamente a `/login`
3. Ingresar credenciales:
   - Usuario: `admin`
   - Contraseña: `admin123`
4. Hacer clic en "Iniciar Sesión"
5. ✅ **Resultado esperado**: Redirección al dashboard

### 1.2 Probar Login Fallido
1. Hacer logout (botón "Cerrar Sesión")
2. Intentar login con credenciales incorrectas:
   - Usuario: `admin`
   - Contraseña: `contraseña_incorrecta`
3. ✅ **Resultado esperado**: Mensaje de error y permanecer en login

---

## 📊 **PASO 2: VERIFICAR DASHBOARD**

### 2.1 Elementos del Dashboard
Después del login exitoso, verificar que el dashboard contenga:
1. ✅ **Estadísticas numéricas**:
   - Total de Servicios
   - Total de Clientes  
   - Total de Facturas
   - Ingresos del Mes

2. ✅ **Gráficos**:
   - Gráfico de servicios más solicitados
   - Gráfico de ingresos mensuales

3. ✅ **Navegación**:
   - Menú lateral con todas las opciones
   - Links funcionando

---

## 🛠️ **PASO 3: CRUD DE SERVICIOS**

### 3.1 Listar Servicios Existentes
1. Ir a: "Servicios" → "Ver Servicios"
2. ✅ **Verificar**: Lista de servicios con datos de prueba
3. ✅ **Verificar**: Botones "Editar" y "Eliminar" en cada servicio

### 3.2 Crear Nuevo Servicio
1. Ir a: "Servicios" → "Nuevo Servicio"
2. Llenar el formulario:
   ```
   Nombre: Impresión Color A4
   Descripción: Impresión a color en papel A4 de alta calidad
   Precio: 0.75
   Categoría: Impresión
   Tiempo Estimado: 5
   Activo: ✓ (marcado)
   ```
3. Hacer clic en "Guardar Servicio"
4. ✅ **Resultado esperado**: Mensaje de éxito y redirección a lista
5. ✅ **Verificar**: El nuevo servicio aparece en la lista

### 3.3 Editar Servicio
1. En la lista de servicios, hacer clic en "Editar" de cualquier servicio
2. Modificar el precio (ejemplo: cambiar a 1.00)
3. Hacer clic en "Actualizar Servicio"
4. ✅ **Resultado esperado**: Cambios guardados y reflejados en la lista

### 3.4 Eliminar Servicio
1. En la lista de servicios, hacer clic en el botón rojo "🗑️" (Eliminar)
2. Aparecerá un modal de confirmación con el nombre del servicio
3. Hacer clic en "Eliminar" para confirmar
4. ✅ **Resultado esperado**: Servicio removido de la lista con mensaje de éxito

---

## 👥 **PASO 4: GESTIÓN DE CLIENTES**

### 4.1 Crear Nuevo Cliente
1. Ir a: "Clientes" → "Nuevo Cliente"
2. Llenar el formulario:
   ```
   Nombre: María González
   Email: maria.gonzalez@email.com
   Teléfono: 0987654321
   Dirección: Av. Principal 123, Quito
   Tipo: individual
   ```
3. Hacer clic en "Guardar Cliente"
4. ✅ **Resultado esperado**: Cliente creado y visible en la lista

### 4.2 Verificar Lista de Clientes
1. Ir a: "Clientes" → "Ver Clientes"
2. ✅ **Verificar**: El nuevo cliente aparece en la lista
3. ✅ **Verificar**: Datos mostrados correctamente

---

## 📄 **PASO 5: SISTEMA DE FACTURACIÓN**

### 5.1 Crear Nueva Factura
1. Ir a: "Facturas" → "Nueva Factura"
2. Llenar el formulario:
   ```
   Cliente: Seleccionar "María González" (recién creado)
   Servicios: Seleccionar 2-3 servicios diferentes
   Cantidades: Poner cantidades variadas (ej: 5, 2, 10)
   ```
3. Hacer clic en "Generar Factura"
4. ✅ **Resultado esperado**: Factura creada con número único

### 5.2 Generar PDF de Factura
1. En la lista de facturas, hacer clic en "Descargar PDF"
2. ✅ **Resultado esperado**: 
   - Descarga automática del PDF
   - PDF contiene todos los datos correctos
   - Cálculos de subtotal, IVA y total correctos

### 5.3 Verificar Cálculos
En el PDF verificar:
- ✅ Subtotal = Suma de (precio × cantidad) de cada servicio
- ✅ IVA = 15% del subtotal
- ✅ Total = Subtotal + IVA

---

## 🎫 **PASO 6: PROMOCIONES QR**

### 6.1 Crear Nueva Promoción QR
1. Ir a: "Promociones" → "Nueva Promoción"
2. Llenar el formulario:
   ```
   Código de Promoción: DESCUENTO20
   Descripción: 20% de descuento en impresiones
   Descuento: 20
   Fecha de Vencimiento: Fecha actual + 30 días
   Máximo Usos: 100
   ```
3. Hacer clic en "Crear Promoción"
4. ✅ **Resultado esperado**: Promoción creada con código QR generado que contiene "DESCUENTO20"

### 6.2 Verificar Código QR Generado
1. En la lista de promociones, verificar que aparece el nuevo código QR
2. ✅ **Verificar**: Se muestra la imagen del código QR
3. ✅ **Verificar**: Al hacer clic en el QR se puede descargar

### 6.3 Validar Promoción QR
1. Ir a: "Promociones" → "Validar QR"
2. Ingresar el código: `DESCUENTO20`
3. Hacer clic en "Validar"
4. ✅ **Resultado esperado**: 
   - Mensaje de validación exitosa
   - Información de la promoción mostrada
   - Contador de usos actualizado

---

## 🏫 **PASO 7: GESTIÓN DE INSTITUCIONES**

### 7.1 Crear Nueva Institución
1. Ir a: "Instituciones" → "Nueva Institución"
2. Llenar el formulario:
   ```
   Nombre: Universidad Central del Ecuador
   Tipo: universidad
   Contacto: Dr. Pedro Martínez
   Email: contacto@uce.edu.ec
   Teléfono: 022234567
   Dirección: Ciudadela Universitaria, Quito
   Descuento: 15
   ```
3. Hacer clic en "Guardar Institución"
4. ✅ **Resultado esperado**: Institución creada correctamente

### 7.2 Verificar Descuento Institucional
1. Crear una nueva factura
2. Al seleccionar cliente, verificar si hay opción para aplicar descuento institucional
3. ✅ **Verificar**: Descuento se aplica automáticamente si corresponde

---

## 📈 **PASO 8: REPORTES Y ESTADÍSTICAS**

### 8.1 Verificar Reportes
1. Ir a: "Reportes"
2. ✅ **Verificar que se muestran**:
   - Reporte de servicios más utilizados
   - Reporte de ingresos por período
   - Estadísticas de clientes
   - Uso de promociones QR

### 8.2 Datos Actualizados en Dashboard
1. Regresar al Dashboard
2. ✅ **Verificar**: Las estadísticas reflejan los nuevos datos creados
3. ✅ **Verificar**: Los gráficos se actualizaron

---

## 🔍 **PASO 9: PRUEBAS DE SEGURIDAD Y NAVEGACIÓN**

### 9.1 Probar Acceso sin Autenticación
1. Hacer logout
2. Intentar acceder directamente a:
   - http://localhost:5000/dashboard
   - http://localhost:5000/servicios
   - http://localhost:5000/clientes
3. ✅ **Resultado esperado**: Redirección automática al login

### 9.2 Navegación del Menú
1. Hacer login nuevamente
2. Probar cada enlace del menú lateral:
   - ✅ Dashboard
   - ✅ Servicios (Ver y Nuevo)
   - ✅ Clientes (Ver y Nuevo)
   - ✅ Facturas (Ver y Nueva)
   - ✅ Promociones (Ver, Nueva, Validar)
   - ✅ Instituciones (Ver y Nueva)
   - ✅ Reportes

---

## 📱 **PASO 10: PRUEBAS DE RESPONSIVIDAD**

### 10.1 Diferentes Tamaños de Pantalla
1. Redimensionar la ventana del navegador
2. ✅ **Verificar**: El diseño se adapta correctamente
3. ✅ **Verificar**: Menú se colapsa en pantallas pequeñas
4. ✅ **Verificar**: Tablas son scrollables horizontalmente

---

## 📋 **CHECKLIST FINAL DE VERIFICACIÓN**

### Funcionalidades Core:
- [ ] ✅ Login/Logout funcionando
- [ ] ✅ Dashboard con estadísticas reales
- [ ] ✅ CRUD Servicios completo
- [ ] ✅ CRUD Clientes completo
- [ ] ✅ Generación de facturas PDF
- [ ] ✅ Creación de promociones QR
- [ ] ✅ Validación de códigos QR
- [ ] ✅ Gestión de instituciones
- [ ] ✅ Reportes actualizados

### Aspectos Técnicos:
- [ ] ✅ Base de datos persistente
- [ ] ✅ Archivos QR generados en `/static/qr_codes/`
- [ ] ✅ PDFs generados correctamente
- [ ] ✅ Cálculos matemáticos precisos
- [ ] ✅ Validaciones de formularios
- [ ] ✅ Mensajes de éxito/error

### Seguridad:
- [ ] ✅ Autenticación requerida
- [ ] ✅ Redirecciones de seguridad
- [ ] ✅ Validación de datos de entrada

---

## 🎯 **DATOS DE PRUEBA SUGERIDOS**

### Servicios de Ejemplo:
```
1. Impresión Láser B/N - $0.10
2. Impresión Láser Color - $0.25
3. Fotocopia A4 - $0.05
4. Escaneado Documento - $0.15
5. Plastificado A4 - $1.50
```

### Clientes de Ejemplo:
```
1. Juan Pérez - individual
2. Ana López - empresarial  
3. Carlos Ruiz - estudiante
```

### Promociones de Ejemplo:
```
1. ESTUDIANTE10 - 10% descuento estudiantes
2. EMPRESA15 - 15% descuento empresas
3. VOLUMEN20 - 20% por volumen alto
```

---

## 🚨 **PROBLEMAS COMUNES Y SOLUCIONES**

### Si el sitio no carga:
```bash
docker ps
docker-compose restart
```

### Si hay problemas con la base de datos:
```bash
docker logs proyecto_diseo_sistemas-db-1
docker-compose down
docker-compose up -d
```

### Si los archivos no se generan:
```bash
docker exec -it proyecto_diseo_sistemas-web-1 ls -la static/
```

---

## ✅ **RESULTADO ESPERADO**

Al completar todas estas pruebas, deberías haber verificado:

1. **Sistema de autenticación seguro**
2. **CRUD completo para todas las entidades**
3. **Generación automática de PDFs**
4. **Sistema de códigos QR funcional**
5. **Cálculos precisos en facturación**
6. **Interface responsive y usable**
7. **Persistencia de datos**
8. **Seguridad básica implementada**

**🎉 ¡EL SISTEMA SERVICEPRO ESTÁ COMPLETAMENTE FUNCIONAL!**
