# Cómo Contribuir a ServicePro

¡Gracias por tu interés en contribuir a ServicePro! Este documento te guiará a través del proceso.

## 📋 Antes de Empezar

1. **Fork** el repositorio
2. **Clona** tu fork localmente
3. **Configura** el entorno de desarrollo

## 🚀 Configuración del Entorno

```bash
# Clonar tu fork
git clone https://github.com/TU-USUARIO/servicepro.git
cd servicepro

# Configurar upstream
git remote add upstream https://github.com/USUARIO-ORIGINAL/servicepro.git

# Instalar dependencias (con Docker)
docker compose up -d
```

## 🔧 Proceso de Desarrollo

### 1. Crear una nueva rama
```bash
git checkout -b feature/nueva-funcionalidad
```

### 2. Hacer cambios
- Sigue las convenciones de código existentes
- Agrega comentarios cuando sea necesario
- Prueba tus cambios localmente

### 3. Probar
```bash
# Reiniciar servicios para probar
docker compose restart

# Verificar que todo funcione
# Ir a http://localhost:5000
```

### 4. Commit
```bash
git add .
git commit -m "feat: descripción clara del cambio"
```

### 5. Push y Pull Request
```bash
git push origin feature/nueva-funcionalidad
```
Luego crear un Pull Request en GitHub.

## 📝 Convenciones

### Commits
- `feat:` Nueva funcionalidad
- `fix:` Corrección de bug
- `docs:` Cambios en documentación
- `style:` Cambios de formato
- `refactor:` Refactorización de código
- `test:` Agregar pruebas
- `chore:` Tareas de mantenimiento

### Código
- Usar nombres descriptivos para variables y funciones
- Seguir PEP 8 para Python
- Agregar docstrings a funciones importantes
- Mantener líneas menores a 120 caracteres

## 🐛 Reportar Bugs

Usa el template de issues para reportar bugs:

1. **Descripción** clara del problema
2. **Pasos** para reproducir
3. **Resultado esperado** vs **resultado actual**
4. **Entorno** (OS, versión de Docker, etc.)

## 💡 Sugerir Funcionalidades

Para nuevas funcionalidades:

1. **Verifica** que no exista ya
2. **Describe** el caso de uso
3. **Explica** el beneficio
4. **Proporciona** ejemplos si es posible

## ✅ Checklist antes del Pull Request

- [ ] El código compila sin errores
- [ ] Todas las funcionalidades existentes siguen funcionando
- [ ] Se agregó documentación si es necesario
- [ ] Se siguieron las convenciones de código
- [ ] Se probó en el entorno de desarrollo

## 🤝 Código de Conducta

- Sé respetuoso con otros contribuidores
- Acepta feedback constructivo
- Mantén un tono profesional
- Ayuda a otros cuando sea posible

## 📞 Contacto

Si tienes preguntas, puedes:
- Crear un issue
- Contactar a los mantenedores
- Unirte a las discusiones del proyecto

¡Gracias por contribuir a ServicePro! 🎉
